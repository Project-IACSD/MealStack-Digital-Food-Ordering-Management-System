package com.app.entities;

public enum OrderStatus {
	PENDING,SERVED;

}
