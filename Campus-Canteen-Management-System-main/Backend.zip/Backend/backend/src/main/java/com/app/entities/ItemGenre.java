package com.app.entities;

public enum ItemGenre {
	SouthIndian, Oriental, NorthIndian, Maharashtrian
}
