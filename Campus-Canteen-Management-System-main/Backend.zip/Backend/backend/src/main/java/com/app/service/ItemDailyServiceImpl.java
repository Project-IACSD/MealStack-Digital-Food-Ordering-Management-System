package com.app.service;

import java.util.List;
import java.time.LocalDate;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dto.ApiResponse;
import com.app.dto.ItemDailyDTO;
import com.app.entities.ItemDaily;
import com.app.entities.ItemMaster;
import com.app.exceptions.ResourceNotFoundException;
import com.app.repository.ItemDailyRepository;
import com.app.repository.ItemMasterRepository;

@Service
@Transactional
public class ItemDailyServiceImpl implements ItemDailyService {

    @Autowired
    private ItemDailyRepository itemRepo;

    @Autowired
    private ItemMasterRepository itemMasRepo;

    @Autowired
    private ModelMapper mapper;

    // ================= GET ALL =================
    @Override
    public List<ItemDailyDTO> getAllDailyItems() {
        return itemRepo.findAll()
                .stream()
                .map(item -> {
                    ItemDailyDTO dto = mapper.map(item, ItemDailyDTO.class);
                    // Manually map fields that might be missed by strict ModelMapper compilation
                    dto.setDailyId(item.getDailyId());
                    dto.setItemId(item.getItem().getId()); // Crucial: Link to Master Item
                    dto.setItemName(item.getItem().getItemName());
                    dto.setItemMasterId(item.getItem().getId());

                    // Added fields for Frontend Display
                    dto.setItemPrice(item.getItem().getItemPrice());
                    dto.setItemImgLink(item.getItem().getItemImgLink());
                    dto.setItemCategory(item.getItem().getItemCategory().toString());

                    return dto;
                })
                .collect(Collectors.toList());
    }

    // ================= ADD =================
    @Override
    public ApiResponse addNewitem(Long itemMasId, ItemDailyDTO dto) {

        ItemMaster itemMaster = itemMasRepo.findById(itemMasId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Item Master ID"));

        // Check if already exists for today
        List<ItemDaily> existingList = itemRepo.findByItemAndDate(itemMaster, LocalDate.now());

        if (!existingList.isEmpty()) {
            // DUPLICATE HANDLING: Pick the first one as primary
            ItemDaily primaryItem = existingList.get(0);

            // Consolidate others if any
            if (existingList.size() > 1) {
                for (int i = 1; i < existingList.size(); i++) {
                    ItemDaily duplicate = existingList.get(i);
                    // Add quantities to primary (optional, but good for data integrity)
                    // primaryItem.setInitialQty(primaryItem.getInitialQty());
                    // We decided to just overwrite with new value or sum?
                    // User's intent is usually "Set daily qty to X".
                    // But if they are just adding, maybe we overwrite.
                    // Let's just DELETE the duplicates to be clean.
                    itemRepo.delete(duplicate);
                }
            }

            // Update primary item with new quantity
            primaryItem.setInitialQty(dto.getInitialQty());
            itemRepo.save(primaryItem);

            return new ApiResponse("Updated existing daily item (and cleaned duplicates): " + itemMaster.getItemName());
        }

        ItemDaily item = new ItemDaily();
        item.setItem(itemMaster); // ✅ FK handled here
        item.setInitialQty(dto.getInitialQty());
        item.setSoldQty(0); // ✅ REQUIRED

        itemRepo.save(item);

        return new ApiResponse(
                "Added item to daily menu: " + itemMaster.getItemName());
    }

    // ================= UPDATE =================
    @Override
    public ItemDailyDTO updateItem(Long dailyId, ItemDailyDTO dto) {

        ItemDaily item = itemRepo.findById(dailyId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Daily Item ID"));

        if (dto.getInitialQty() != null) {
            item.setInitialQty(dto.getInitialQty());
        }

        if (dto.getSoldQty() != null) {
            item.setSoldQty(dto.getSoldQty());
        }

        return mapper.map(item, ItemDailyDTO.class);
    }

    // ================= GET ONE =================
    @Override
    public ItemDailyDTO getItemDetails(Long dailyId) {
        ItemDaily item = itemRepo.findById(dailyId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Daily Item ID"));

        return mapper.map(item, ItemDailyDTO.class);
    }

    // ================= DELETE ONE =================
    @Override
    public ApiResponse deleteItemDetails(Long dailyId) {

        ItemDaily item = itemRepo.findById(dailyId)
                .orElseThrow(() -> new ResourceNotFoundException("Item not found"));

        itemRepo.delete(item);

        return new ApiResponse(
                "Daily item deleted with ID " + dailyId);
    }

    // ================= DELETE ALL =================
    @Override
    public ApiResponse deleteAllDailyItems() {
        itemRepo.deleteAll();
        return new ApiResponse("All daily items deleted");
    }
}
