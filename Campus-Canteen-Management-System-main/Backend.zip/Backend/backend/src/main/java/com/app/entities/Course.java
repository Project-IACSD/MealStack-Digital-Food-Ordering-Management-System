package com.app.entities;

public enum Course {
	DAC,DBDA,DAI,DITISS ;
}
