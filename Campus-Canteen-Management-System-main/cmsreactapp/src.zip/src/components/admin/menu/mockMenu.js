export const mockData=[{
    id:1,
    item_name: "Poha",
    item_price: 20,
    item_time: "Breakfast"
},
{
    id:2,
    item_name: "Misal",
    item_price: 30,
    item_time: "Breakfast"
},
{
    id:3,
    item_name: "Thali",
    item_price: 50,
    item_time: "Lunch"
},
{
    id:4,
    item_name: "Bhel",
    item_price: 20,
    item_time: "Snacks"
},
{
    id:5,
    item_name: "Thali",
    item_price: 50,
    item_time: "Dinner"
},
{
    id:6,
    item_name: "Tea",
    item_price: 10,
    item_time: "Beverages"
},
{
    id:7,
    item_name: "Sweets",
    item_price: 10,
    item_time: "Lunch"
}
]