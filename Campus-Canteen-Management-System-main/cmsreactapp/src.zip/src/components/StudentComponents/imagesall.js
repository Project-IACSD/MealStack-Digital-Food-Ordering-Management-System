import vadapav from '../../Images/vada_pav.jpg'
import samosa from '../../Images/samosa.jpg'
import tea from '../../Images/tea.jpg'
import coffee from '../../Images/coffee.jpg'
import idli from '../../Images/idli.jpg'
import food from '../../Images/food.jpg'
import logo from '../../Images/logo-no-background.png'


export default{
    vadapav,
    tea,
    coffee,
    samosa,
    idli,
    food,
    logo
};