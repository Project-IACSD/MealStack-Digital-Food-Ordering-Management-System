import React, { useEffect, useState } from 'react'
import { Box, Typography, useTheme, Button } from "@mui/material";
import { tokens } from "../../theme";
import { DataGrid, GridActionsCellItem } from "@mui/x-data-grid";
import Header from "../admin/common/Header";
import RechargeHistoryService from '../../services/RechargeHistoryService.jsx';
import { getStudentId } from '../../utils/jwtUtils';
import { useNavigate } from "react-router-dom";

export default function RechargeHistoryTable() {
  const [rechargeHistory, setRechargeHistory] = useState([]);
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const navigate = useNavigate();

  const colStructure = [
    {
      headerName: "Transaction Id",
      field: "transactionId",
      type: "number",
      headerAlign: "left",
      align: "left",
    },
    {
      headerName: "Amount Added",
      field: "amountAdded",
      type: "number",
      headerAlign: "left",
      align: "left",
    },
    {
      headerName: "Time Stamp",
      field: "timeStamp",
      headerAlign: "left",
      align: "left",
      width: 200,
    },
    {
      headerName: "Student Id",
      field: "studentId",
      type: "number",
      headerAlign: "left",
      align: "left",
    },
  ];

  useEffect(() => {
    const studentId = getStudentId();
    if (studentId) {
      RechargeHistoryService.getAllRechargeHistoryByStudentId(Number(studentId)).then((res) => {
        // Handle both array response and object with data property
        // Robust check: Ensure result is an array
        let data = Array.isArray(res) ? res : (res?.data && Array.isArray(res.data) ? res.data : []);

        // Log warning if data is unexpected structure but not triggering crash
        if (!Array.isArray(data)) {
          console.warn("API returned non-array data:", res);
          data = [];
        }

        setRechargeHistory(data);
      })
        .catch((err) => {
          console.error(err);
        });
    }
  }, []);

  return (
    <Box m="20px">
      <Header
        title="Recharge History"
        subtitle=""
      ></Header>
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[800],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[800],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
        }}
      >
        <DataGrid
          getRowId={(row) => row.transactionId}
          rows={rechargeHistory}
          columns={colStructure}
          initialState={{
            pagination: { paginationModel: { pageSize: 5 } },
          }}
          pageSizeOptions={[5, 10, 25]}
        ></DataGrid>
      </Box>
    </Box>
  );
}
