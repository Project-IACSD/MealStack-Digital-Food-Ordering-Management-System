import React, { useState, useEffect } from "react";
import { Box, useTheme, Typography } from "@mui/material";
import { tokens } from "../../theme";
import { DataGrid } from "@mui/x-data-grid";
import Header from "../admin/common/Header";
import { useNavigate } from "react-router-dom";
import OrderService from "../../services/OrderService";
import { getStudentId } from "../../utils/jwtUtils";


export default function OrderHistoryTable() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const studentId = getStudentId();
        if (studentId) {
          const data = await OrderService.getOrdersByStudentId(studentId);
          setOrders(Array.isArray(data) ? data : []);
        }
      } catch (err) {
        console.error(err);
      }
    }
    fetchOrders();
  }, []);

  const columns = [
    {
      headerName: "Order Id",
      field: "orderId",
      type: "number",
      flex: 1,
    },
    {
      headerName: "Order Qty",
      field: "qty",
      type: "number",
      flex: 1,
    },
    {
      headerName: "Amount",
      field: "amount",
      type: "number",
      flex: 1,
    },
    // Add Status or Date if available in backend
    {
      headerName: "Status",
      field: "status",
      flex: 1
    }
  ];

  const handleRowClick = (params) => {
    navigate(`/student/orders/display/${params.id}`, {
      state: params.row,
    });
  };

  return (
    <Box m="20px">
      <Header title="Order History" subtitle="Your past orders" />

      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": { border: "none" },
          "& .MuiDataGrid-cell": { borderBottom: "none" },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[800],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[800],
          },
        }}
      >
        <DataGrid
          getRowId={(row) => row.orderId}
          rows={orders}
          columns={columns}
          onRowClick={handleRowClick}
          pageSizeOptions={[5, 10, 25]}
          initialState={{
            pagination: { paginationModel: { pageSize: 5 } },
          }}
        />
      </Box>
    </Box>
  );
}
