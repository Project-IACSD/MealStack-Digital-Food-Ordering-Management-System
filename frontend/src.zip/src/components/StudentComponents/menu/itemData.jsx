import samosa from '../../../assets/samosa.jpg'
import vadapav from '../../../Images/vada_pav.jpg'
import coffee from '../../../Images/coffee.jpg'
import idli from '../../../Images/idli.jpg'
import pavbhaji from '../../../assets/pavbhaji.jpg'
import meduvada from '../../../Images/meduvada.jpg'
export const itemData = [
    {
    id: 10,
    name: "Coffee",
    img_link:
    coffee,
    qty: 10,
    price: 20,
  },
  {
    id: 20,
    name: "Idli",
    img_link:
    idli,
    qty: 10,
    price: 20,
  },
  {
    id: 30,
    name: "Medu Vada",
    img_link:
    meduvada,
       qty: 10,
    price: 20,
  },
  {
    id: 40,
    name: "Pav Bhaji",
    img_link:
    pavbhaji,
      qty: 10,
    price: 20,
  },
  
  {
    id: 60,
    name: "Samosa",
    img_link: samosa,     
    qty: 10,
    price: 20,
  },
  
  {
    id: 90,
    name: "Vadapav",
    img_link:
      vadapav,
    qty: 10,
    price: 20,
  }
]
