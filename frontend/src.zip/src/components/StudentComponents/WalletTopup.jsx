import React from "react";
import { Box, Button, TextField } from "@mui/material";
import { Field, Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import Header from "../admin/common/Header";
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import EditIcon from "@mui/icons-material/Edit";
import StudentService from "../../services/studentService";
import RechargeHistoryService from "../../services/RechargeHistoryService";
import { useNavigate } from "react-router-dom";

export default function WalletTopup() {
  const navigate = useNavigate();
  const isNonMobile = useMediaQuery("(min-width:600px)");

  const initValues = {
    id: Number(localStorage.getItem("studentId")),
    addAmount: ""
  }

  const nameRegex = /^[a-zA-Z]+ [a-zA-Z]+$/;
  const mobRegex = /[789][0-9]{9}/;

  const studentSchema = yup.object().shape({
    addAmount: yup
      .number()
      .typeError("Amount must be a number")
      .min(100, "Minimum amount is ₹100")
      .max(5000, "Maximum amount is ₹5000")
      .required("Required")
  });

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };

  const handleFormSubmit = async (values) => {
    if (values.addAmount === "") {
      alert("please enter amount");
      return;
    }

    const res = await loadRazorpayScript();
    if (!res) {
      alert("Razorpay SDK failed to load. Are you online?");
      return;
    }

    if (window.Razorpay) {
      var options = {
        key: "rzp_test_AtG9VVI9mbh1sa",
        key_secret: "yoRzFyCuMHwMGWR31mvB6ldZ",
        amount: values.addAmount * 100,
        currency: "INR",
        name: "Campus Canteen System",
        description: "Wallet Top-up",
        handler: async function (response) {
          try {
            // Call API to add history (Backend will now also update balance)
            await RechargeHistoryService.addRechargeHistory({
              studentId: values.id,
              amountAdded: Number(values.addAmount),
              // timeStamp handled by backend
              paymentId: response.razorpay_payment_id, // Store Razorpay ID in paymentId field
              transactionId: 0 // Optional, backend ignores/overwrites
            });
            alert("Payment Successful! Balance Updated.");
            navigate("/student/rechargehistory");
          } catch (error) {
            console.error("Topup failed", error);
            // Extract meaningful error message
            let errorMessage = "Topup recorded failed, please contact admin.";
            if (error.response && error.response.data) {
              // If it's a map (Validation errors)
              if (typeof error.response.data === 'object' && !error.response.data.message) {
                errorMessage = "Validation Fail: " + JSON.stringify(error.response.data);
              } else {
                errorMessage = error.response.data.message || error.response.data;
              }
            } else if (error.message) {
              errorMessage = error.message;
            }
            alert(errorMessage);
          }
        },
        prefill: {
          name: "Student",
          email: `student${values.id}@examples.com`,
          contact: "9999999999",
        },
        theme: {
          color: "#3399cc",
        },
      };
      var pay = new window.Razorpay(options);
      pay.open();
    } else {
      alert("Razorpay SDK not loaded. Please wait and try again.");
    }
  }

  return (

    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      minHeight={"100vh"}
    >
      <Box border={"1px solid black"} m={"20px"} p="20px" borderRadius={5}>
        <Header title={"Top-Up Wallet"} subtitle={"Add Amount"}></Header>
        <Formik
          onSubmit={handleFormSubmit}
          initialValues={initValues}
          validationSchema={studentSchema}
        >
          {({
            values,
            errors,
            touched,
            handleBlur,
            handleChange,
            handleSubmit,
          }) => {
            return (
              <form onSubmit={handleSubmit}>
                <Box
                  width={"300px"}
                  display="grid"
                  gap="30px"
                  gridTemplateColumns="repeat(4, minmax(0, 1fr))"
                  sx={{
                    "& > div": {
                      gridColumn: isNonMobile ? undefined : "span 4",
                    },
                  }}
                >


                  <TextField
                    fullWidth
                    variant="filled"
                    type="text"
                    inputMode="numeric"
                    label="Amount to be added"
                    placeholder="Enter amount (100-5000)"

                    onBlur={handleBlur}
                    onChange={handleChange}
                    value={values.addAmount}
                    name="addAmount"
                    error={!!touched.addAmount && !!errors.addAmount}
                    helperText={touched.addAmount && errors.addAmount}
                    sx={{ gridColumn: "span 4" }}
                  />


                </Box>
                <Box display="flex" justifyContent="end" mt="20px">
                  <Button type="submit" color="secondary" variant="contained" >
                    <span><EditIcon />&nbsp;&nbsp;Update Balance</span>
                  </Button>
                </Box>
              </form>
            );
          }}
        </Formik>
      </Box>
    </Box>

  )
}
