import React from 'react';
import { Box, Button, Grid, TextField, CircularProgress } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../../theme";
import { DataGrid } from "@mui/x-data-grid";
import Header from "../common/Header";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import DeleteIcon from "@mui/icons-material/Delete";

export default function ItemDailyTable({ items = [], onUpdateQuantity, onRemoveItem, onConfirm, loading = false }) {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);

    const colStructure = [
        {
            headerName: "ID",
            field: "id",
            flex: 0.5,
            minWidth: 50,
        },
        {
            headerName: "Item Name",
            field: "itemName",
            flex: 2,
            minWidth: 150,
        },
        {
            headerName: "Price",
            field: "itemPrice",
            type: "number",
            headerAlign: "left",
            align: "left",
            flex: 1,
            minWidth: 100,
        },
        {
            headerName: "Quantity",
            field: "initialQty",
            flex: 1,
            minWidth: 120,
            renderCell: (params) => {
                const id = params.row.id;
                return (
                    <TextField
                        type='number'
                        variant="outlined"
                        size="small"
                        inputProps={{ min: 1, style: { padding: '5px' } }}
                        value={params.row.initialQty}
                        onChange={(e) => onUpdateQuantity(id, e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        sx={{ width: "80px" }}
                    />
                )
            }
        },
        {
            headerName: "Actions",
            field: "actions",
            flex: 1,
            minWidth: 100,
            renderCell: (params) => {
                return (
                    <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => onRemoveItem(params.row.id)}
                    >
                        <DeleteIcon />
                    </Button>
                )
            }
        }
    ];

    return (
        <Box m="20px">
            <Header
                title="Daily items"
                subtitle="Menu items for today"
            />
            <Box
                m="40px 0 0 0"
                height="75vh"
                sx={{
                    "& .MuiDataGrid-root": {
                        border: "none",
                    },
                    "& .MuiDataGrid-cell": {
                        borderBottom: "none",
                    },
                    "& .name-column--cell": {
                        color: colors.greenAccent[300],
                    },
                    "& .MuiDataGrid-columnHeaders": {
                        backgroundColor: colors.blueAccent[800],
                        borderBottom: "none",
                    },
                    "& .MuiDataGrid-virtualScroller": {
                        backgroundColor: colors.primary[400],
                    },
                    "& .MuiDataGrid-footerContainer": {
                        borderTop: "none",
                        backgroundColor: colors.blueAccent[800],
                    },
                    "& .MuiCheckbox-root": {
                        color: `${colors.greenAccent[200]} !important`,
                    },
                }}
            >
                <DataGrid
                    getRowId={(row) => row.id}
                    rows={items}
                    columns={colStructure}
                    disableRowSelectionOnClick
                    pageSizeOptions={[5, 10, 25]}
                    autoHeight
                    initialState={{
                        pagination: { paginationModel: { pageSize: 5 } },
                    }}
                />
            </Box>

            <Grid container spacing={2} sx={{ mt: "10px" }}>
                <Grid size={12}>
                    <Button
                        variant="contained"
                        sx={{
                            backgroundColor: colors.greenAccent[600],
                            width: "100%",
                            padding: "10px",
                            "&:disabled": {
                                backgroundColor: colors.primary[400],
                            }
                        }}
                        onClick={onConfirm}
                        disabled={items.length === 0 || loading}
                    >
                        {loading ? (
                            <CircularProgress size={24} color="inherit" />
                        ) : (
                            <>
                                <CheckCircleIcon />
                                &nbsp;&nbsp;Confirm Daily Menu
                            </>
                        )}
                    </Button>
                </Grid>
            </Grid>
        </Box >
    );
}
