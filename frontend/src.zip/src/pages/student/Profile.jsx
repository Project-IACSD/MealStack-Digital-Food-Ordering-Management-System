import { useState, useEffect } from 'react';
import StudentService from '../../services/student.service';
import { useAuth } from '../../context/AuthContext';

const Profile = () => {
    const { user } = useAuth();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        mobileNo: '',
        courseName: '',
        dob: ''
    });
    const [message, setMessage] = useState('');

    useEffect(() => {
        if (user && (user.id || user.studentId)) {
            const id = user.id || user.studentId;
            StudentService.getProfile(id).then(data => {
                setFormData({
                    name: data.name || '',
                    email: data.email || '',
                    mobileNo: data.mobileNo || '',
                    courseName: data.courseName || '',
                    dob: data.dob || ''
                });
            });
        }
    }, [user]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const id = user.id || user.studentId;
            await StudentService.updateProfile(id, formData);
            setMessage('Profile updated successfully!');
        } catch (error) {
            console.error(error);
            setMessage('Failed to update profile.');
        }
    };

    return (
        <div className="card" style={{ maxWidth: '600px', margin: '0 auto' }}>
            <h2>Edit Profile</h2>
            {message && <div className={message.includes('success') ? "success-message" : "error-message"}>{message}</div>}
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="form-label">Name</label>
                    <input name="name" className="form-input" value={formData.name} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label className="form-label">Email</label>
                    <input name="email" className="form-input" value={formData.email} onChange={handleChange} disabled />
                </div>
                <div className="form-group">
                    <label className="form-label">Mobile No</label>
                    <input name="mobileNo" className="form-input" value={formData.mobileNo} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label className="form-label">Course</label>
                    <input name="courseName" className="form-input" value={formData.courseName} onChange={handleChange} disabled />
                </div>
                <button type="submit" className="btn">Update Profile</button>
            </form>
        </div>
    );
};

export default Profile;
