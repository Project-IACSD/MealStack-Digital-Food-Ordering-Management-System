import { useEffect, useState } from 'react';
import StudentService from '../../services/student.service';
import { useAuth } from '../../context/AuthContext';
import { Link } from 'react-router-dom';

const StudentDashboard = () => {
    const { user } = useAuth();
    const [balance, setBalance] = useState(0);
    const [profile, setProfile] = useState(null);

    useEffect(() => {
        if (user && user.id) {
            fetchData(user.id);
        } else if (user && user.studentId) {
            fetchData(user.studentId);
        }
        // If we don't have ID in user object, we can't fetch.
        // Assuming user object from login has id.
    }, [user]);

    const fetchData = async (id) => {
        try {
            const balanceData = await StudentService.getBalance(id);
            setBalance(balanceData); // Backend returns number or { balance: 100 }?
            // User said "GET /student/{id}/balance". 
            // Often returns just a number or simple object.
            // Let's assume response.data is the balance or object.
            // If object: setBalance(balanceData.balance)

            const profileData = await StudentService.getProfile(id);
            setProfile(profileData);
        } catch (error) {
            console.error("Error fetching dashboard data", error);
        }
    };

    return (
        <div>
            <h1>Student Dashboard</h1>
            <div style={{ display: 'grid', gap: '1rem', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))' }}>
                <div className="card">
                    <h3>Wallet Balance</h3>
                    <p style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--success-color)' }}>
                        ₹{typeof balance === 'object' ? balance.balance : balance}
                    </p>
                    <Link to="/student/profile" className="btn" style={{ marginTop: '1rem', textAlign: 'center' }}>Top Up / Update</Link>
                </div>

                <div className="card">
                    <h3>My Profile</h3>
                    {profile ? (
                        <div>
                            <p><strong>Name:</strong> {profile.name}</p>
                            <p><strong>Email:</strong> {profile.email}</p>
                            <p><strong>Course:</strong> {profile.courseName}</p>
                        </div>
                    ) : (
                        <p>Loading profile...</p>
                    )}
                    <Link to="/student/profile" className="btn" style={{ marginTop: '1rem', textAlign: 'center' }}>Edit Profile</Link>
                </div>
            </div>
        </div>
    );
};

export default StudentDashboard;
