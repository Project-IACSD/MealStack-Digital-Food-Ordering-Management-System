import React, { useState, useEffect } from "react";
import ItemDailyService from "../../services/ItemDailyService";
import { Link, useNavigate } from "react-router-dom";
import { Box, Typography, Button, Grid, Card, CardMedia, CardContent, CardActions, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";
import defimg from '../../assets/pick-meals-image.png';

export default function MenuList() {
  const [menuItems, setMenuItems] = useState([]);
  const [order, setOrder] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const items = await ItemDailyService.getAllItemsDaily(); // Or getAvailableItems() depending on logic
        console.log("Fetched daily items:", items);

        // Map backend daily item structure to frontend expectations if needed
        // DailyItem might contain nested ItemMaster details or flat structure
        // Assuming flat structure based on previous Admin work: id, itemName, itemPrice
        setMenuItems(Array.isArray(items) ? items : []);
      } catch (error) {
        console.error("Error fetching menu items:", error);
        setMenuItems([]);
      }
    };
    fetchMenuItems();
  }, []);

  const addToOrder = (item) => {
    const updatedOrder = { ...order };
    updatedOrder[item.id] = (updatedOrder[item.id] || 0) + 1;
    setOrder(updatedOrder);
  };

  const removeFromOrder = (item) => {
    const updatedOrder = { ...order };
    if (updatedOrder[item.id] > 0) {
      updatedOrder[item.id] -= 1;
      setOrder(updatedOrder);
    }
  };

  const totalAmount = Object.keys(order).reduce((total, itemId) => {
    const menuItem = menuItems.find(
      (item) => item.id === parseInt(itemId)
    );
    return total + (menuItem ? menuItem.itemPrice * order[itemId] : 0);
  }, 0);

  const placeOrder = () => {
    // Transform order object to list of items for checkout
    const orderList = Object.keys(order).map(itemId => {
      const item = menuItems.find(i => i.id === parseInt(itemId));
      return {
        ...item,
        quantity: order[itemId]
      }
    }).filter(i => i.quantity > 0);

    navigate("/student/placeorder", { state: { order: orderList, totalAmount } });
  }

  return (
    <Box p={3} sx={{ backgroundColor: '#fcfcfc', minHeight: '100vh' }}>
      <Typography variant="h3" align="center" gutterBottom color="primary" fontWeight="bold">
        Food Menu Selection
      </Typography>

      <Grid container spacing={3} justifyContent="center">
        {menuItems.map((item) => (
          <Grid item key={item.id} xs={12} sm={6} md={4} lg={3}>
            <Card sx={{ maxWidth: 345, borderRadius: '15px', boxShadow: 3 }}>
              <CardMedia
                component="img"
                height="140"
                image={item.imageLink || defimg}
                alt={item.itemName}
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="div" fontWeight="bold">
                  {item.itemName}
                </Typography>
                <Typography variant="h6" color="secondary">
                  ₹{item.itemPrice}
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'space-between', px: 2, pb: 2 }}>
                <Button
                  variant="contained"
                  color="error"
                  size="small"
                  onClick={() => removeFromOrder(item)}
                  disabled={!order[item.id]}
                >
                  -
                </Button>
                <Typography variant="h6">{order[item.id] || 0}</Typography>
                <Button
                  variant="contained"
                  color="success"
                  size="small"
                  onClick={() => addToOrder(item)}
                >
                  +
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
        {menuItems.length === 0 && (
          <Typography variant="h6" color="text.secondary" sx={{ mt: 4 }}>
            No menu items available for today.
          </Typography>
        )}
      </Grid>

      {/* Cart Summary */}
      <Box mt={8} p={3} component={Paper} elevation={3}>
        <Typography variant="h4" align="center" gutterBottom>
          Order Checkout List
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell align="center"><strong>Name</strong></TableCell>
                <TableCell align="center"><strong>Price</strong></TableCell>
                <TableCell align="center"><strong>Quantity</strong></TableCell>
                <TableCell align="center"><strong>Subtotal</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.keys(order).filter(id => order[id] > 0).map((itemId) => {
                const menuItem = menuItems.find(
                  (item) => item.id === parseInt(itemId)
                );
                if (!menuItem) return null;
                return (
                  <TableRow key={itemId}>
                    <TableCell align="center">{menuItem.itemName}</TableCell>
                    <TableCell align="center">₹{menuItem.itemPrice}</TableCell>
                    <TableCell align="center">{order[itemId]}</TableCell>
                    <TableCell align="center">₹{menuItem.itemPrice * order[itemId]}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box mt={3} textAlign="center">
          <Typography variant="h4" color="primary" gutterBottom>
            Total Amount: ₹ {totalAmount.toFixed(2)}
          </Typography>
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={placeOrder}
            disabled={totalAmount === 0}
            sx={{ px: 5, py: 1.5, fontSize: '1.2rem' }}
          >
            Place Order
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
