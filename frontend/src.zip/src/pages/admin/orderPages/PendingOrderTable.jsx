import React, { useState, useEffect } from "react";
import { Box, Typography, useTheme, Button } from "@mui/material";
import { tokens } from "../../../theme";
import { DataGrid, GridActionsCellItem } from "@mui/x-data-grid";
import Header from "../../../components/admin/common/Header";
import DeleteIcon from "@mui/icons-material/Delete";
import { useNavigate } from "react-router-dom";
import OrderService from "../../../services/OrderService";

export default function PendingOrderTable() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const navigate = useNavigate();
  const [pendingOrders, setPendingOrders] = useState([]);

  useEffect(() => {
    loadPendingOrders();
  }, []);

  const loadPendingOrders = async () => {
    try {
      const data = await OrderService.getPendingOrders();
      setPendingOrders(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Failed to load pending orders", error);
      // setPendingOrders([]); // Optional: set empty or show error
    }
  };

  const cancelOrder = async (event, params) => {
    event.stopPropagation();
    // Use navigate to delete page, passing current order data
    navigate("/admin/orders/delete/" + params.id, { state: params.row });
  };

  const displayOrder = (params) => {
    navigate("/admin/orders/display/" + params.id, { state: params.row });
  };

  const colStructure = [
    {
      headerName: "Order Id",
      field: "orderId",
      type: "number",
      headerAlign: "left",
      align: "left",
      flex: 1,
    },
    {
      headerName: "Person Name",
      field: "name", // Ensure backend sends 'name' or 'studentName'
      type: "text",
      headerAlign: "center",
      align: "center",
      flex: 1,
    },
    {
      headerName: "Order Qty",
      field: "qty",
      type: "number",
      headerAlign: "left",
      align: "left",
      flex: 1,
    },
    {
      headerName: "Amount",
      field: "amount",
      type: "number",
      headerAlign: "left",
      align: "left",
      flex: 1,
    },
    {
      headerName: "Action",
      type: "actions",
      headerAlign: "left",
      align: "left",
      flex: 1,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<DeleteIcon />}
          label="Delete"
          onClick={(event) => cancelOrder(event, params)}
        />,
      ],
    },
  ];

  return (
    <Box m="20px">
      <Header
        title="Pending Orders"
        subtitle="Pending Orders for today"
      ></Header>
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[800],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[800],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
        }}
      >
        <DataGrid
          getRowId={(row) => row.orderId}
          rows={pendingOrders}
          columns={colStructure}
          onRowClick={displayOrder}
          initialState={{
            pagination: { paginationModel: { pageSize: 5 } },
          }}
          pageSizeOptions={[5, 10, 25]}
        />
      </Box>
    </Box>
  );
}
