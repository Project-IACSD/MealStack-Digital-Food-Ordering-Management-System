import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  Tabs,
  Tab,
  Alert,
  CircularProgress
} from '@mui/material';

import { useTheme } from '@mui/material/styles';
import { tokens } from '../theme';

function Login() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [tabValue, setTabValue] = useState(0); // 0 = Student, 1 = Admin
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { studentLogin, adminLogin } = useAuth();
  const navigate = useNavigate();

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
    setError('');
    setEmail('');
    setPassword('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let result;
      if (tabValue === 0) {
        // Student Login
        result = await studentLogin(email, password);
        if (result.success) {
          navigate('/student/dashboard');
        }
      } else {
        // Admin Login
        result = await adminLogin(email, password);
        if (result.success) {
          navigate('/admin/dashboard');
        }
      }
    } catch (err) {
      const errorMessage = err?.message || err?.toString() || 'Login failed. Please check your credentials.';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 8 }}>
      <Paper elevation={3} sx={{
        p: 4,
        backgroundColor: colors.primary[400],
        color: colors.grey[100]
      }}>
        <Typography variant="h4" component="h1" gutterBottom align="center" sx={{ color: colors.grey[100], fontWeight: 'bold' }}>
          Campus Canteen Management
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom align="center" sx={{ color: colors.greenAccent[500] }}>
          Login
        </Typography>

        <Box sx={{ borderBottom: 1, borderColor: colors.grey[100], mb: 3 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            centered
            sx={{
              '& .MuiTab-root': { color: colors.grey[100] },
              '& .Mui-selected': { color: colors.greenAccent[500] + ' !important' },
              '& .MuiTabs-indicator': { backgroundColor: colors.greenAccent[500] }
            }}
          >
            <Tab label="Student Login" />
            <Tab label="Admin Login" />
          </Tabs>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            margin="normal"
            required
            autoComplete="email"
            sx={{
              '& .MuiInputLabel-root': { color: colors.grey[100] },
              '& .MuiInputBase-input': { color: colors.grey[100] },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: colors.grey[100] },
                '&:hover fieldset': { borderColor: colors.greenAccent[500] },
                '&.Mui-focused fieldset': { borderColor: colors.greenAccent[500] },
              },
            }}
          />

          <TextField
            fullWidth
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            margin="normal"
            required
            autoComplete="current-password"
            sx={{
              '& .MuiInputLabel-root': { color: colors.grey[100] },
              '& .MuiInputBase-input': { color: colors.grey[100] },
              '& .MuiOutlinedInput-root': {
                '& fieldset': { borderColor: colors.grey[100] },
                '&:hover fieldset': { borderColor: colors.greenAccent[500] },
                '&.Mui-focused fieldset': { borderColor: colors.greenAccent[500] },
              },
            }}
          />

          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{
              mt: 3,
              mb: 2,
              backgroundColor: colors.blueAccent[600],
              color: colors.grey[100],
              '&:hover': { backgroundColor: colors.blueAccent[700] }
            }}
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} sx={{ color: colors.grey[100] }} /> : 'Login'}
          </Button>
        </form>

        <Box textAlign="center" mt={2}>
          <Typography variant="body2" sx={{ color: colors.grey[100] }}>
            Don't have an account?{' '}
            <Button
              variant="text"
              size="small"
              onClick={() => navigate('/register')}
              disabled={tabValue === 1} // Only show for students
              sx={{ color: colors.greenAccent[500] }}
            >
              Register here
            </Button>
          </Typography>
        </Box>
      </Paper>
    </Container>
  );
}

export default Login;
